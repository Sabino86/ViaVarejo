Dado("que eu esteja no resultado da busca do iPhone") do
      visit 'https://casasbahia.com.br'
      busca.preencher_busca
      busca.clicar
  end
  
  Quando("eu clicar em comparar os dois primeiros iPhones da lista") do
      comparar.selecionar
  end
  
  Quando("clicar no botao Comparar") do
      comparar.compare
  end
  
  Entao("deve trazer os dados de Comparacao") do
    comparar.pagina
  end
  
  Entao("validar pelo menos tres dados iguais") do
      verificar.valor
  end