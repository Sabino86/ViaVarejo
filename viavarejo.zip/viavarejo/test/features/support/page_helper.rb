Dir[File.join(File.dirname(__FILE__), "../pages/*>page.rb")].each {|file| require file}

module Pages
    def busca
        @busca ||= Busca.new
    end   
    def comparar
        @comparar ||= Comparar.new
    end
    def verificar
        @verificar ||= Verificar.new
    end
end