class Comparar < SitePrism::Page
    element :botao, '.nm-btn-compare'
    element :texto, '.tit'

    def selecionar
        page.execute_script("window.scrollBy(0,750)")
        find('label[for="comparator-product-6883912"]').click
        find('label[for="comparator-product-11656724"]').click
    end

    def compare
        botao.click
    end

    def pagina
        page.assert_text(text, 'Resultado da Comparação')
        page.execute_script("window.scrollBy(0,2000)")
    end
end