class Verificar < SitePrism::Page
    elements :lista, 'tr > td'

   def valor
        if lista[7].text == lista[8].text && lista[9].text == lista[10].text && lista[11].text && lista[12].text
        
            puts ' 3 dados iguais'
       
        end
   end

end

