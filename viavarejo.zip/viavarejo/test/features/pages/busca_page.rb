class Busca < SitePrism::Page
        set_url '/Site/ComparacaoProduto.aspx?ProdutosCompara=6883912,11656724&ReturnUrl=https://www.casasbahia.com.br/busca?q=iphone'
        element :busca, '#strBusca'
        element :lupa, '#btnOK'    
        
        def clicar
            lupa.click
        end
        
        def preencher_busca
            busca.set 'iPhone'
        end   

end

